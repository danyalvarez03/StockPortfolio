run:
Company: MyCompany
Shares Held: 3
The value per share is $33 6/8
Opening Portfolio Value: $101.25
Change in price per share is $3 3/8
The updated value per share is $37 1/8
Updated Portfolio Value: $111.38
Change in price per share is $3 3/8
The final value per share is $40 4/8
Final Portfolio Value: $121.50
BUILD SUCCESSFUL (total time: 23 seconds)
